
//
// This is example code from Chapter 3.8 "Types and objects" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

#include "std_lib_facilities.h"

//------------------------------------------------------------------------------

int main()
{
    int a = 7; 
    int b = 9; 
    char c = 'a';
    double x = 1.2;
    string s1 = "Hello, world";
    string s2 = "1.2";
}

//------------------------------------------------------------------------------
