
//
// This is example code from Chapter 4.3.2 "Operators" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

//------------------------------------------------------------------------------

int main()
{
    int a = 0;

    // An increment can be expressed in at least three ways:
    ++a;
    a+=1;
    a=a+1;
}

//------------------------------------------------------------------------------
