
//
// This is example code from Chapter 8.6.2 "Global initialization" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

int x1 = 1;
int y1 = x1+2;        // y1 becomes 3
