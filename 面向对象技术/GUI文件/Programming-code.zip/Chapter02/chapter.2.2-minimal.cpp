
//
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

//------------------------------------------------------------------------------

// The minimal C++ program is simply

int main() { }

//------------------------------------------------------------------------------
