
//
// This is example code from Chapter 8.3 "Header Files" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

int f(int);
