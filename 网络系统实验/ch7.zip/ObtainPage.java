package obtain;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.htmlparser.Node;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.util.NodeIterator;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class ObtainPage {
	//public String url="http://www.chenmo.biz";
	public ObtainPage()
	{
		//this.url=url;
	}
	public URL verifyUrl(String url) {//exchange the string url to the element URL
	    // ֻ����HTTP URLs.
	    if (!url.toLowerCase().startsWith("http://"))
	      return null;
	    URL verifiedUrl = null;
	    try {
	      verifiedUrl = new URL(url);
	    } catch (Exception e) {
	      return null;
	    }
	    return verifiedUrl;
	  }
	
	 public String downloadPage(URL pageUrl) { 
	     try {
	        // Open connection to URL for reading.  	 
	    	InputStreamReader in=new InputStreamReader(pageUrl.openStream(),"utf-8");
	        BufferedReader reader =  new BufferedReader(in);
	        // Read page into buffer.
	        String line;
	        StringBuffer pageBuffer = new StringBuffer();
	        while ((line = reader.readLine()) != null) {
	        	pageBuffer.append(line);
	        }    
	        return pageBuffer.toString();
	     } catch (Exception e) {
	     }
	     return null;
	  }
	
	/**
	 * @param args
	 * @throws ParserException 
	 */
	public static void main(String[] args) throws ParserException {
		// TODO Auto-generated method stub
		String url="http://www.chenmo.biz";
		ObtainPage op=new ObtainPage(); 
		String page=op.downloadPage(op.verifyUrl(url));
		Parser parser = Parser.createParser(page, "utf-8");
		/*for test1
		 for (NodeIterator i = parser.elements (); i.hasMoreNodes(); ) {
             Node node = i.nextNode();
             message("getText:"+node.getText());
             message("getPlainText:"+node.toPlainTextString());
             message("toHtml:"+node.toHtml());
             message("toHtml(true):"+node.toHtml(true));
             message("toHtml(false):"+node.toHtml(false));
             message("toString:"+node.toString());
             message("=================================================");
         }   
		*/
		NodeFilter filter1=new HasAttributeFilter("class","contentbox");
		NodeList nodes = parser.extractAllNodesThatMatch(filter1);
		for (int i = 0; i < nodes.size(); i++) {
    		Node nodet = nodes.elementAt(i);
    		String temp=nodet.toPlainTextString().trim();
    		message(temp);
		}
		System.out.println("end");
		//System.out.println(page);
	}
	private static void message(String string) {
		// TODO Auto-generated method stub
		System.out.println(string);
	}

}
